package org.horaapps.leafpic.data;

/**
 * Created by dnld on 6/28/17.
 */

public interface IAlbum {
    String getName();
    String getPath();
    int getCount();
    Media getCover();
}
