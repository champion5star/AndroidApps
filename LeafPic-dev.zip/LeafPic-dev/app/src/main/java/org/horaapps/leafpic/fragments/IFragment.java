package org.horaapps.leafpic.fragments;

/**
 * Created by dnld on 3/24/17.
 */

public interface IFragment {

    boolean editMode();
    boolean clearSelected();
}
