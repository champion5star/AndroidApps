package com.martin.ads.omoshiroilib.filter.ext;

import android.content.Context;

/**
 * Created by Ads on 2017/1/27.
 * BraSizeTestRightFilter (罩杯测试.右)
 * To measure size of Bra, have fun~ :D
 */

public class BraSizeTestRightFilter extends DrawImageFilter{

    public BraSizeTestRightFilter(Context context) {
        super(context,"filter/imgs/bra_right.png");
    }
}
