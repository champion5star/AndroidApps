package com.martin.ads.omoshiroilib.imgeditor;

import android.content.Context;
import android.view.View;
import android.view.animation.Animation;

/**
 * Created by Ads on 2017/8/1.
 */

public class MiscUtils {
    public static boolean isNull(String str){
        return str==null || str.isEmpty();
    }
}
