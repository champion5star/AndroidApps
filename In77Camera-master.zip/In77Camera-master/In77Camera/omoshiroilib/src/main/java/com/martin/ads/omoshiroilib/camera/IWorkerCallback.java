package com.martin.ads.omoshiroilib.camera;

public interface IWorkerCallback {
    void onPostExecute(Exception exception);
}