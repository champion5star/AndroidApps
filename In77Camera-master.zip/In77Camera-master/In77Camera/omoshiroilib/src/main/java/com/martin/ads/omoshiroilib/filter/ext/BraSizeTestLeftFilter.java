package com.martin.ads.omoshiroilib.filter.ext;

import android.content.Context;

/**
 * Created by Ads on 2017/1/27.
 * BraSizeTestLeftFilter (罩杯测试.左)
 * To measure size of Bra, have fun~ :D
 */

public class BraSizeTestLeftFilter extends DrawImageFilter{

    public BraSizeTestLeftFilter(Context context) {
        super(context, "filter/imgs/bra_left.png");
    }
}
