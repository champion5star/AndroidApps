package com.martin.ads.omoshiroilib.filter.effect.xiuxiuxiu;

import android.content.Context;

/**
 * Created by Ads on 2017/4/6.
 */

public class CoralFilter extends XiuXiuXiuFilterWrapper {
    public CoralFilter(Context context) {
        super(context,"Coral");
    }
}
