package com.martin.ads.omoshiroilib.debug.removeit;

import android.content.Context;

/**
 * Created by Ads on 2017/2/13.
 */

public class GlobalConfig {
    public static final boolean FULL_SCREEN=true;
    public static final boolean PREVIEW_WHEN_SHOT=true;
    public static final String In77Camera_PHOTO_PATH ="/In77Camera/Photos/";
    public static final String In77Camera_VIDEO_PATH="/In77Camera/Videos/";
    public static Context context=null;
}
