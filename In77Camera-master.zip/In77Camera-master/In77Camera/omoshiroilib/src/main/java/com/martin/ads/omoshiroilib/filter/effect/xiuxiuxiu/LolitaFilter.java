package com.martin.ads.omoshiroilib.filter.effect.xiuxiuxiu;

import android.content.Context;

/**
 * Created by Ads on 2017/4/6.
 */

public class LolitaFilter extends XiuXiuXiuFilterWrapper {
    public LolitaFilter(Context context) {
        super(context,"Lolita");
    }
}
