package com.martin.ads.omoshiroilib.constant;

/**
 * Created by Ads on 2017/1/26.
 */

public class GLEtc {
    public static final int NO_TEXTURE=0;
    //i.e. GLES11Ext.GL_TEXTURE_EXTERNAL_OES
    public static final int GL_TEXTURE_EXTERNAL_OES = 0x8D65;
}
