package com.martin.ads.omoshiroilib.constant;

/**
 * Created by Ads on 2017/5/31.
 */

public class MimeType {
    public static final int VIDEO=0;
    public static final int PHOTO=1;
}
