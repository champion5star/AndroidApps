package com.martin.ads.omoshiroilib.filter.helper;

/**
 * Created by Ads on 2017/2/18.
 */

public enum FilterTypeExt {
    //Effects
    SCALING,
    BOX_BLUR,
    GAUSSIAN_BLUR,
    RANDOM_BLUR,
    FAST_BLUR,
    BLURRED_FRAME
}
