![banner](https://user-images.githubusercontent.com/30379002/45506407-b95fcf80-b754-11e8-8585-26d307085dc7.jpg)
# In77Camera
![progress](http://progressed.io/bar/30?title=Progress)

# Preview
![ScreenShot](https://github.com/Martin20150405/In77Camera/blob/master/screenshots/camera_preview.png)

![ScreenShot](https://github.com/Martin20150405/In77Camera/blob/master/screenshots/camera_preview_2.png)

![ScreenShot](https://github.com/Martin20150405/In77Camera/blob/master/screenshots/demo_cap1.png)

![ScreenShot](https://github.com/Martin20150405/In77Camera/blob/master/screenshots/demo_cap2.png)

