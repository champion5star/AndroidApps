package ir.cafebazaar.notepad.activities.editfolders;

/**
 * Created by MohMah on 8/19/2016.
 */
interface OpenCloseable{
	void close();

	void open();

	boolean isOpen();
}
