[![No Maintenance Intended](http://unmaintained.tech/badge.svg)](http://unmaintained.tech/)

Android Month Calendar Widget Demo
==================================

A simple example of a responsive Month Calendar app widget for Android 4.1+.

<img src="https://raw.github.com/romannurik/Android-MonthCalendarWidget/master/hero.png">
